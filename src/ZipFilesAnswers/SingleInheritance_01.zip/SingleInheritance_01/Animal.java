package SingleInheritance_01;

public class Animal {


    public void est (){
        System.out.println("eating…");
    }

}
